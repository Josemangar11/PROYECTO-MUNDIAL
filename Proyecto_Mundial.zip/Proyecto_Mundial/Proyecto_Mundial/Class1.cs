﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Simulacion
{
    public class Equipo
    {
        public string Nombre_Equipo = "";
        public int Partidos_ganados = 0;
        public int Partidos_empatados = 0;
        public int Partidos_perdidos = 0;
    }
}
