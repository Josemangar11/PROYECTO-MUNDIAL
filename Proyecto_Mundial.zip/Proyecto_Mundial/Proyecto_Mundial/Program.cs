﻿using Proyecto_Simulacion;
using System;

Equipo[,] equipos = new Equipo[8, 4];

opciones:
Console.WriteLine("Menú: ");
Console.WriteLine("1. Ingresar equipos");
Console.WriteLine("2. Editar Equipos");
Console.WriteLine("3. Mostrar Información ingresada");
Console.WriteLine("4. Iniciar Simulación");
Console.WriteLine("5. Salir");

    int opcion_menu = int.Parse(Console.ReadLine());
    switch (opcion_menu)
    {
        case 1:
            Console.Clear();
            int ciclo = 1;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.WriteLine("Ingrese el nombre del equipo " + ciclo);
                    equipos[i, j].Nombre_Equipo = Console.ReadLine();

                    do  
                    {
                        Console.WriteLine("Ingrese los partidos ganados de ese equipo: ");
                        equipos[i, j].Partidos_ganados = int.Parse(Console.ReadLine());
                    } while (equipos[i, j].Partidos_ganados < 0);

                    do  
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos empatados de ese equipo: ");
                    equipos[i, j].Partidos_empatados = int.Parse(Console.ReadLine());
     
                    } while (equipos[i, j].Partidos_empatados < 0);

                    do 
                    {
                        Console.WriteLine("Ingrese la cantidad de partidos perdidos de ese equipo: ");
                        equipos[i, j ].Partidos_perdidos = int.Parse(Console.ReadLine());
                    } while (equipos[i, j].Partidos_perdidos < 0);
                    
                    
                    ciclo++;
                    Console.Clear();

                }                               
            }

        break;

        case 2:
   
            Console.Clear();

            Console.WriteLine("Qué número de equipo quieres editar?");
            int opcion_equipo = int.Parse(Console.ReadLine());
            if (opcion_equipo < 8 || opcion_equipo >= 0)
    
            for (int j = 0; j < 4; j++)
            {
                Console.WriteLine("Ingrese los datos del equipo [ " + opcion_equipo + " ] :");
                equipos[opcion_equipo, j].Nombre_Equipo = Console.ReadLine();
                Console.WriteLine("Ingrese la cantidad de partidos ganados de ese equipo: ");
                equipos[opcion_equipo, j].Partidos_ganados = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese la cantidad de partidos empatados de ese equipo: ");
                equipos[opcion_equipo, j].Partidos_empatados = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese la cantidad de    partidos perdidos de ese equipo: ");
                equipos[opcion_equipo, j].Partidos_perdidos = int.Parse(Console.ReadLine());
            }
            break;

        case 3:
            
          Console.Clear();
        int contador = 1;
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.WriteLine("El equipo  " + contador + " es " + equipos[i, j].Nombre_Equipo);
                Console.WriteLine("Partidos Ganados: " + equipos[i, j].Partidos_ganados);
                Console.WriteLine("Partidos Empatados: " + equipos[i, j].Partidos_empatados);
                Console.WriteLine("Partidos Perdidos: " + equipos[i, j].Partidos_perdidos);
            }
            contador++;
        }

        break;

        case 4:
            break;

        case 5:
        break;       

    }
